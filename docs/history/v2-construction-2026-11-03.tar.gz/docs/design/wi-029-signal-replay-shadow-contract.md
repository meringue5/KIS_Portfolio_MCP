# WI-029 — Signal replay, calibration and shadow contract

## Severity and bootstrap rule set

The canonical four levels are `normal` (정상), `watch` (주의), `warning` (경고) and `critical` (긴급).
Delivery eligibility starts at rank 1, `watch`. Migration `0013` adds the numeric floor because the earlier
transport ledger's coarse `minimum_delivery_severity` column cannot express `watch`; the earlier migration checksum
is not edited.

Bootstrap boundaries are the owner-approved Package D values, not production claims:

| Signal | watch | warning | critical |
| --- | ---: | ---: | ---: |
| absolute daily return | `max(3%, 2*vol20)` | `max(5%, 3*vol20)` | `max(8%, 4*vol20)` |
| absolute KRW portfolio contribution | 0.25 percentage points | 0.75 pp | 1.50 pp |
| position-episode drawdown | -8% | -12% | -20% |
| planned loss / portfolio value | 1.5% | 2.0% | 2.5% or stop breach |

Price at or below SMA20, RSI14 30/70 and Bollinger 20/2 are context only. Price shock plus volume/SMA20 at least
1.5 strengthens one level; 2.5 is high-volume context. A close below SMA50 with SMA20 below SMA50 and a drawdown
condition is at least warning. If fewer than 20 valid bars exist, volatility and volume rules are unavailable while
absolute return and contribution remain evaluable.

ETF, REIT, leveraged and inverse products are evaluated as their own listed instruments. Look-through is unavailable.
Asset-class calibration changes only a versioned absolute-boundary multiplier chosen from an explicit candidate grid;
it never silently changes the approved formula or overwrites a used rule version.

해외 보유상품의 `stock`/`reit` 분류는 이름 heuristic을 쓰지 않는다. KIS `CTPF1702R`의 exact symbol과
상품분류, SEC submissions의 exact ticker/CIK/SIC가 모두 일치할 때만 official-reference evidence로 채택한다.
SEC SIC 6798은 REIT로, 그 외 KIS 해외주식 상품은 equity로 분류하며, identity 또는 상품분류가 모호하면
`unknown`으로 남긴다. 실제 보유 symbol은 공개 저장소 문서에 기록하지 않는다.

## Replay semantics

- Input is sorted by evaluation time, slot and opaque subject before evaluation.
- Every observation declares `historical_live` or `retrospective_reconstructed`; reconstructed data may calibrate a
  boundary but is never labelled as an old live alert.
- Non-pass quality is counted and produces no alert state.
- The daily budget target is median at most 2 and nearest-rank p95 at most 5 stateful delivery candidates per
  evaluation slot. Raw active observations are reported separately; only entry, escalation, changed signal set,
  recovery and re-entry count toward the budget, using the same de-duplication semantics as WI-028.
- Asset-class candidates are first checked independently, then the selected profile combination must pass the same
  budget again after all held asset classes are combined. A per-class pass cannot hide a noisy total slot.
- "False positive" and "miss" are owner-review labels. Until labels exist, the report exposes only transparent
  proxies: top candidate episodes and the maximum adverse observation below watch. It must not claim precision.
- A three-year report states actual date span and coverage by asset class. Review readiness requires at least 1,096
  calendar days from first to last eligible session and at least 600 distinct eligible session dates per observed
  asset class. A short or class-missing window remains `insufficient_history`; fixture success does not satisfy
  production acceptance.

## Shadow and approval

Shadow is DB-only. `control.alert_shadow_windows` requires external send count zero and records expected/observed
sessions, candidates, de-duplication, quality suppression and sensitive-value violations. A window cannot be verified
until at least 14 elapsed days, expected governed slots are reconciled, sensitive violations are zero and owner review
is complete.

Candidate presence does not prove that a slot completed. Before the WI-029-S06 cutover, a slot is observed only when
every candidate has a terminal outcome and every delivery-required transition has a completed shadow claim with a
sent internal attempt. From 2026-09-08 onward, even a zero-candidate slot additionally requires the deterministic
`shadow-slot-terminal-v1` quality marker written after the whole shadow evaluation returns successfully. The partial
2026-09-03 14:30 run remains an explicit `MOTHERDUCK_COMMIT_FAILED_A152C99C` exception; it is not backfilled or
relabeled as live success. The corrected acceptance window is 2026-09-01 through 2026-09-14, excluding pre-activation
2026-08-28 slots and retaining the original window as immutable incident evidence.

`control.alert_rule_approval_revisions` is owner-only and references both a review-ready calibration run and a verified
shadow window. Approval does not itself enable Telegram; WI-030 owns destination verification, test message and the
external delivery feature flag.

S04 reuses the three fixed owned-portfolio Cloud Run Jobs. Each run lands both raw and adjusted operational-strict
daily bars before evaluating; `kr-1000` also evaluates the exact prior U.S. close session. The runtime records only
shadow-channel claims and internal completed attempts. The deploy target applies migration 0013 before updating those
jobs and verifies a private GCS backup/download/fresh restore; neither the migration nor verify Job receives KIS or
Telegram credentials.

The exact U.S. market session, not the later Korean Scheduler date, owns candidate identity. When a U.S. holiday makes
`kr-1000` select a session already evaluated on an earlier Korean date, the prior immutable candidate is retained and
the observation is counted as `reused_session`; it creates no candidate, state transition or delivery. A same-date
candidate whose governed content changes remains a hard conflict.

## Cost and safety

Replay reads governed MotherDuck rows and makes zero provider calls. It is a bounded, terminating analytical job.
Shadow reuses the three scale-to-zero monitoring slots; it creates no always-on worker and has no Telegram secret or
network adapter. Reports use opaque subject hashes and aggregate counts, never account numbers or absolute total
asset values.
